import argparse
import subprocess
import os
import re
import socket
import threading
import hashlib

host_name=socket.gethost_name()
now_ip=socket.gethostbyname(host_name) #取得當前docker的ip

def transaction(arg1,arg2,money):
    with open('block.txt','r') as f:
        Sha=f.readlines()
    dir_path = './'
    pattern = re.compile(r'\d+\.txt') 
    files=[]
    for file_name in os.listdir(dir_path):
        if pattern.match(file_name):
            file_path = os.path.join(dir_path, file_name)
            files.append(int(file_name[:-4]))
    if len(files) != max(files):
        print('Lost file!')
    else:
        find_txt(len(Sha),max(files),arg1,arg2,money)
    
def find_txt(s,e,arg1,arg2,money):
    if s >= 20:
        if e-s == 0:
            e+=1
        i=s
        while i <= e:
            if not os.path.exists(f'{i}.txt'):
                Tcom=os.system(rf"touch {i}.txt")
                with open('block.txt','r') as f:
                    Sha=f.readlines()
                Sha[-1]=Sha[-1].split()
                Sha256=Sha[-1][0]
                if Sha[-1][1] == f'{i-1}.txt':
                    with open(f'{i}.txt','a') as f:
                        f.write(f'Sha256 of previous block: {Sha256}\n')
                        f.write(f'Next block: {i+1}.txt\n')
                        f.write(arg1+', '+arg2+', '+str(money)+'\n')                    
                    print('success')
                    break
                else:
                    print('block.txt error!')
                    break
            else:
                with open(f'{i}.txt','r') as f:
                    data=f.readlines()
                if len(data)==7:
                    if i == 20:
                        if not os.path.exists(f'{i+1}.txt'):
                            e+=1
                        i+=1
                        continue
                    else:
                        com=f'sha256sum {i}.txt >> block.txt'
                        com_a=os.system(com)
                        if not os.path.exists(f'{i+1}.txt'):
                            e+=1
                        i+=1
                        continue
                elif len(data)==0:
                    with open('block.txt','r') as f:
                        Sha=f.readlines()
                    Sha[-1]=Sha[-1].split()
                    Sha256=Sha[-1][0]
                    if Sha[-1][1] == f'{i-1}.txt':
                        with open(f'{i}.txt','a') as f:
                            f.write(f'Sha256 of previous block: {Sha256}\n')
                            f.write(f'Next block: {i+1}.txt\n')
                            f.write(arg1+', '+arg2+', '+str(money)+'\n')                        
                        print('success')
                        break
                    else:
                        print('block.txt error!')
                        break
                
                else:
                    with open(f'{i}.txt','a') as f:
                        f.write(arg1+', '+arg2+', '+str(money)+'\n')                    
                    print('success')
                    break
                return None
    else:
        print('Not having at least 20 txts!')
        return None

def checkmoney(arg1):
    def filenumber():
        initial_count = 0
        folder='./'
        for path in os.listdir(folder):
            if path[-2:] != 'py' and path != 'block.txt':
                initial_count+=1
        return initial_count
    total=0
    num=filenumber()
    for i in range(1,num+1):
        with open (f'{i}.txt','r') as f:
            data=f.readlines()
            if len(data)>2:
                for j in range(2,len(data)):
                    d=data[j].split(', ')
                    if d[0]==arg1:
                        total-=int(d[2])
                    elif d[1]==arg1:
                        total+=int(d[2])
    print(f'{arg1} have $',total)
    return 0

def checkLog(arg1):
    initial_count = 0
    folder='./'
    for path in os.listdir(folder):
        if path[-2:] != 'py' and path != 'block.txt':
            initial_count += 1
    num = initial_count
    transaction = ''
    for i in range(1, num+1):
        with open(f'{i}.txt','r') as f:
            row=f.readlines()
            ccount=1
            small_t=''
            for k in range(2,len(row)):
                k=row[k].split(', ')
                str_k=k[0]+' -> '+k[1]+' '+k[2]+''
                for j in k:
                    if arg1==j:
                        if ccount==1:
                            small_t+=f'{i}.txt\n'
                            ccount+=1
                        small_t+=str_k
            if small_t != '':
                small_t+='\n'
            else:
                continue
            transaction+=small_t
            if len(row)!=7 or i==num:
                print(transaction)
    return 0

def checkChain(arg1):
    with open('block.txt', 'r') as f:
        Sha = f.readlines()
    check_true = 0
    bool = True
    error_list = []
    if len(Sha) != 0:
        for i in range(1, len(Sha)+1):
            filename = f'{i}.txt'
            result = subprocess.check_output(['sha256sum', filename])
            hash_value = result.decode().split()[0]
            Sha[i-1]=Sha[i-1].split()
            Sha256=Sha[i-1][0]
            if filename == Sha[i-1][1]:
                if hash_value == Sha256:
                    print(f'{i}.txt correct!')
                    check_true += 1
                else:                    
                    bool = False
                    error_list.append(Sha256 + f'{i}.txt')
                    print(f'{i}.txt error!')
            else:
                print('block.txt error!')
                break
    else:
        print('block.txt have no data!') 
    if bool == True:
        print("OK")
    else:
        print("This id Error Sha256")
        for item in error_list:
            print(item)
    #檢查後給10元
    print('Angel give you bonus 10 dollars!')
    transaction('angle',arg1,10)
    angle_give=f'transaction angle {arg1} 10'
    for peer in node.peers:
        node.sock.sendto(angle_give.encode('utf-8'), peer)

#下兩個def為checkallchains用
def calculate_sha256(file_path): #計算雜湊值(會將最大數字txt傳入)
    with open(file_path, 'rb') as f:
        sha256 = hashlib.sha256()
        while True:
            data = f.read(8192)
            if not data:
                break
            sha256.update(data)
    return sha256.hexdigest()

def max_file(): #取得最大數字txt路徑
    dir_path = './'
    pattern = re.compile(r'\d+\.txt') 
    files=[]
    for file_name in os.listdir(dir_path):
        if pattern.match(file_name):
            file_path = os.path.join(dir_path, file_name)
            files.append(int(file_name[:-4]))
    while True:    
        max_file = max(files)
        max_file_str=str(max_file)+'.txt'
        max_file_path = os.path.join(dir_path, max_file_str)
        with open(max_file_path, 'r') as f:
            file_data = f.readlines()    
            if len(file_data)==0:
                files.remove(max_file)
                continue
            else:
                return os.path.join(dir_path, max_file_str)

def dockername(ip):
    if ip == '172.17.0.2': #myDB
        return 'client1'
    if ip == '172.17.0.3': #myMachine1
        return 'client2'
    if ip == '172.17.0.4': #myMachine2
        return 'client3'

class P2PNode:
    def __init__(self, port, peers):
        self.port = port
        self.peers = peers
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        host_name=socket.gethost_name()
        now_ip=socket.gethostbyname(host_name)
        self.sock.bind((now_ip, self.port)) #此docker的ip

    def start(self):
        threading.Thread(target=self._listen).start()
        threading.Thread(target=self._send_message_split).start()

    def _listen(self):
        while True:
            data, addr = self.sock.recvfrom(1024)
            data_split = data.decode('utf-8').split()
            if not data_split:
                continue
            data_split[0]=data_split[0].lower()
            if len(data_split) == 4 and data_split[0] == 'transaction':
                la = data_split[1]
                lb = data_split[2]
                lmoney = data_split[3]
                transaction(la, lb, int(lmoney))
                print(f"\nReceived {data.decode('utf-8')} from docker {addr} !")
            elif len(data_split) == 4 and data_split[0] == 'getmaxsha': 
                ipname=dockername(now_ip)
                print(f"\nReceived {data.decode('utf-8')} from docker {addr} !")
                max_sha = calculate_sha256(max_file())
                print('this sha ',max_sha, len(max_sha))
                print(data)
                print(data.decode('utf-8'))
                if data_split[3] == max_sha:
                    answer=f"{now_ip} max number txt {max_file()} sha256 {max_sha} {len(max_sha)} correct!"
                    print('check sha ',max_sha,len(max_sha))
                else:
                    answer=f"{now_ip} max number txt {max_file()} sha256 {max_sha} {len(max_sha)} error!"
                    print('check sha ',max_sha, len(max_sha))
                for peer in self.peers:
                    self.sock.sendto(answer.encode('utf-8'), peer)
                #檢查後給100元
                transaction('angle',data_split[1],100)                
            else:
                print(f"\nReceived {data.decode('utf-8')} from docker {addr} !")


    def _send_message_split(self):
        while True:
            message = input("\nEnter a message(eg.) : \n (checklog A , checkmoney B , transaction B A 1000, checkChain A, checkallchains B) \n")
            message_split=message.split()
            comlist=['transaction','checkmoney','checklog','checkchain','checkallchains']
            if message_split[0] in comlist:
                if len(message_split)==2 and message_split[0].lower() == 'checkallchains':
                    max_sha = calculate_sha256(max_file())
                    getmaxshastr=f'getmaxsha {message_split[1]} {now_ip} {max_sha}'
                    print(f'max number txt: {max_file()} , sha: {max_sha} , lengh: {len(max_sha)}')
                    for peer in self.peers:
                        self.sock.sendto(getmaxshastr.encode('utf-8'), peer)                        
                    #檢查後給100元
                    transaction('angle',message_split[1],100)
                elif len(message_split)==2:
                    global a
                    m=message_split[0]
                    a=message_split[1]
                    m=m.lower()
                    if m == 'checklog':
                        checkLog(a)    
                    if m == 'checkmoney':
                        checkmoney(a)
                    if m == 'checkchain':
                        checkChain(a)
                    else:
                        for peer in self.peers:
                            self.sock.sendto(message.encode('utf-8'), peer)
                elif len(message_split)==4:
                    m=message_split[0]
                    a=message_split[1]
                    b=message_split[2]
                    money=message_split[3]
                    m=m.lower()
                    if m == 'transaction':
                        transaction(a,b,int(money))
                        for peer in self.peers:
                            self.sock.sendto(message.encode('utf-8'), peer)
                    else:
                        for peer in self.peers:
                            self.sock.sendto(message.encode('utf-8'), peer)
                else:
                    for peer in self.peers:
                        self.sock.sendto(message.encode('utf-8'), peer)
            else:
                print('\n error command !\n')

if __name__ == '__main__':
    port = 8001
    ip_list=['172.17.0.2','172.17.0.3','172.17.0.4']
    ip_list.remove(now_ip)
    peers = [(ip_list[0], 8001), (ip_list[1], 8001)]  #自身外其他兩個docker
    node = P2PNode(port, peers)
    node.start()

