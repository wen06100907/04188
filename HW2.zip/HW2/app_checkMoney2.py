import argparse
import os
import re

parser = argparse.ArgumentParser()
parser.add_argument('User_1')
args=parser.parse_args()


def checkMoney():
    initial_count = 0
    folder = './'
    regex = r"^\d+\.txt$"
    for path in os.listdir(folder):
        if re.match(regex, path):
            initial_count += 1
    return initial_count

total = 0
num = checkMoney()
for i in range(1,num+1):
    with open (f'{i}.txt','r') as f:
        row = f.readlines()
        if len(row)>2:
            for j in range(2,len(row)):
                x = row[j].split(', ')
                if x[0] == args.User_1:
                    total -= int(x[2])
                elif x[1] == args.User_1:
                    total += int(x[2])
print(f'{args.User_1} have $',total)