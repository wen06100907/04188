import argparse
import os
import re

parser = argparse.ArgumentParser()
parser.add_argument('User_1')
args=parser.parse_args()

def checkLog():
    initial_count = 0
    folder = './'
    regex = r"^\d+\.txt$"
    for path in os.listdir(folder):
        if re.match(regex, path):
            initial_count += 1
    return initial_count

num=checkLog()
transaction=''

for i in range(1,num+1):
    with open(f'{i}.txt','r') as f:
        row=f.readlines()
        ccount=1
        if i > 1:
            transaction += '\n'
        for k in range(2,len(row)):
            k = row[k].split(', ')
            str_k = k[0] + ' -> ' + k[1] + ' ' + k[2] + ''
            for j in k:
                if args.User_1 == j:
                    if ccount == 1:
                        transaction += f'{i}.txt\n'
                        ccount += 1
                    transaction += str_k
        if len(row) != 7 or i == num:
            print(transaction)
            break
