import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument('User_1')
parser.add_argument('User_2')
parser.add_argument('money',type=int)
args=parser.parse_args()

def Block(x,y):
    for i in range(x,y):
        if not os.path.exists(f'{i}.txt'):
            os.system(rf"touch {i}.txt")

        if not os.path.exists(f'{i+1}.txt'):
            os.system(rf"touch {i+1}.txt")
        with open(f'{i}.txt','r') as f:
            row=f.readlines()

        if len(row)==0:
            with open('block.txt','r') as f:
                Sha=f.readlines()

            if not Sha:
                Sha256 = ""
            else:
                Sha[i-2]=Sha[i-2].split()
                Sha256=Sha[i][0]
            with open(f'{i}.txt','a') as f:
                f.write(f'Sha256 of previous block: {Sha256}\n')
                f.write(f'Next block: {i+1}.txt\n')
                f.write(args.User_1+', '+args.User_2+', '+str(args.money)+'\n')
            break
        elif len(row)==6:
            with open(f'{i}.txt','a') as f:
                f.write(args.User_1+', '+args.User_2+', '+str(args.money)+'\n')
            com=f'sha256sum {i}.txt >> block.txt'
            os.system(com)
            with open('block.txt','r') as f:
                Sha=f.readlines()
            if not Sha:
                Sha256 = ""
            else:
                Sha[i-1]=Sha[i-1].split()
                Sha256=Sha[i-1][0]
            with open(f'{i+1}.txt','a') as f:
                f.write(f'Sha256 of previous block: {Sha256}\n')
                f.write(f'Next block: {i+1+1}.txt\n')
            break
        elif len(row)==7:
            continue
        else:
            with open(f'{i}.txt','a') as f:
                f.write(args.User_1+', '+args.User_2+', '+str(args.money)+'\n')
            break

        return None

if not os.path.exists(f'block.txt'):
    os.system(rf"touch block.txt")
with open('block.txt','r') as f:
    Sha=f.readlines()

Block(1,len(Sha)+2)
print('success')