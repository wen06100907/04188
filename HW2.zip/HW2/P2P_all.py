import socket
import threading
import os
import argparse
import subprocess
import re
import hashlib
import time

hostname=socket.gethostname()
ip_address=socket.gethostbyname(hostname) #取得當前docker的ip

def getstrname(ip):
    if ip == '172.17.0.2': #myDB
        return 'client1'
    if ip == '172.17.0.3': #myMachine1
        return 'client2'
    if ip == '172.17.0.4': #myMachine2
        return 'client3'

#def get_peer_max_sha(peer):
#    msg = 'getmaxsha'
#    node.sock.sendto(msg.encode('utf-8'), peer)
#    data, addr = node.sock.recvfrom(1024)
#    peer_max_sha = data.decode('utf-8').strip()
#    max_sha = calculate_sha256(get_max_file())
#    if max_sha != peer_max_sha:
#        print(f'{peer} has a different max sha: {peer_max_sha}')
#    else:
#        print(f'{peer} has the same max sha as me.')
#    return peer_max_sha

def calculate_sha256(file_path): #計算雜湊值(會將最大數字txt傳入)
    with open(file_path, 'rb') as f:
        sha256 = hashlib.sha256()
        while True:
            data = f.read(8192)
            if not data:
                break
            sha256.update(data)
    return sha256.hexdigest()

def get_max_file(): #取得最大數字txt路徑
    dir_path = './'
    pattern = re.compile(r'\d+\.txt') 
    files=[]
    for file_name in os.listdir(dir_path):
        if pattern.match(file_name):
            file_path = os.path.join(dir_path, file_name)
            files.append(int(file_name[:-4]))
    while True:    
        max_file = max(files)
        max_file_str=str(max_file)+'.txt'
        max_file_path = os.path.join(dir_path, max_file_str)
        with open(max_file_path, 'r') as f:
            file_data = f.readlines()    
            if len(file_data)==0:
                files.remove(max_file)
                continue
            else:
                sha256F = calculate_sha256(f'{max_file_path}')
                return os.path.join(dir_path, max_file_str)

def transaction(arg1,arg2,argMoney):
    with open('block.txt','r') as f:
        Sha=f.readlines()
    #檢查
    dir_path = './'
    pattern = re.compile(r'\d+\.txt') 
    files=[]
    for file_name in os.listdir(dir_path):
        if pattern.match(file_name):
            file_path = os.path.join(dir_path, file_name)
            files.append(int(file_name[:-4]))
    if len(files) != max(files):
        print('Lost txt file!')
    else:
        loop_txt(len(Sha),max(files),arg1,arg2,argMoney)
    
def loop_txt(s,e,arg1,arg2,argMoney):
    if s >= 20:
        if e-s == 0:
            e+=1
        i=s
        while i <= e:
            if not os.path.exists(f'{i}.txt'):
                Tcom=os.system(rf"touch {i}.txt")
                with open('block.txt','r') as f:
                    Sha=f.readlines()
                Sha[-1]=Sha[-1].split()
                Sha256=Sha[-1][0]
                if Sha[-1][1] == f'{i-1}.txt':
                    with open(f'{i}.txt','a') as f:
                        f.write(f'Sha256 of previous block: {Sha256}\n')
                        f.write(f'Next block: {i+1}.txt\n')
                        f.write(arg1+', '+arg2+', '+str(argMoney)+'\n')
                    #print('transfer money ......')
                    #print(f'now money save on {i}.txt')
                    print('success')
                    break
                else:
                    print('block.txt error!')
                    break
            else:
                with open(f'{i}.txt','r') as f:
                    data=f.readlines()
                if len(data)==7:
                    if i == 20:
                        if not os.path.exists(f'{i+1}.txt'):
                            e+=1
                        i+=1
                        continue
                    else:
                        com=f'sha256sum {i}.txt >> block.txt'
                        com_a=os.system(com)
                        if not os.path.exists(f'{i+1}.txt'):
                            e+=1
                        i+=1
                        continue
                elif len(data)==0:
                    with open('block.txt','r') as f:
                        Sha=f.readlines()
                    Sha[-1]=Sha[-1].split()
                    Sha256=Sha[-1][0]
                    if Sha[-1][1] == f'{i-1}.txt':
                        with open(f'{i}.txt','a') as f:
                            f.write(f'Sha256 of previous block: {Sha256}\n')
                            f.write(f'Next block: {i+1}.txt\n')
                            f.write(arg1+', '+arg2+', '+str(argMoney)+'\n')
                        #print('transfer money ......')
                        #print(f'money save on {i}.txt')
                        print('success')
                        break
                    else:
                        print('block.txt error!')
                        break
                
                else:
                    with open(f'{i}.txt','a') as f:
                        f.write(arg1+', '+arg2+', '+str(argMoney)+'\n')
                    #print('transfer money ......')
                    #print(f'money save on {i}.txt')
                    print('success')
                    break
                return None
    else:
        print('Not having at least 20 txts!')
        return None

def checkChain(arg1):
    with open('block.txt', 'r') as f:
        Sha = f.readlines()
    checkTrue = 0
    if len(Sha) != 0:
        for i in range(1, len(Sha)+1):
            filename = f'{i}.txt'
            result = subprocess.check_output(['sha256sum', filename])
            hash_value = result.decode().split()[0]
            Sha[i-1]=Sha[i-1].split()
            Sha256=Sha[i-1][0]
            if filename == Sha[i-1][1]:
                if hash_value == Sha256:
                    print(f'{i}.txt check correct!')
                    checkTrue += 1
                else:
                    print(f'{i}.txt check error!')
            else:
                print('block.txt error!')
                break
    else:
        print('block.txt have no data!')
    
    #檢查後給10元
    print('Angel give you bonus 10 dollars!')
    transaction('angle',arg1,10)
    for_mess=f'transaction angle {arg1} 10'
    for peer in node.peers:
        node.sock.sendto(for_mess.encode('utf-8'), peer)

def checkMoney(arg1):
    def count_filenumbers():
        initial_count = 0
        folder='./'
        for path in os.listdir(folder):
            if path[-2:] != 'py' and path != 'block.txt':
                initial_count+=1
        return initial_count

    total=0
    num=count_filenumbers()
    for i in range(1,num+1):
        with open (f'{i}.txt','r') as f:
            data=f.readlines()
            if len(data)>2:
                for j in range(2,len(data)):
                    d=data[j].split(', ')
                    if d[0]==arg1:
                        total-=int(d[2])
                    elif d[1]==arg1:
                        total+=int(d[2])
    print(f'{arg1} have $',total)
    return 0

def checkLog(arg1):
    initial_count = 0
    folder='./'
    for path in os.listdir(folder):
        if path[-2:] != 'py' and path != 'block.txt':
            initial_count += 1

    num = initial_count
    transaction = ''
    for i in range(1, num+1):
        with open(f'{i}.txt','r') as f:
            data=f.readlines()
            ccount=1
            small_t=''
            for k in range(2,len(data)):
                k=data[k].split(', ')
                str_k=k[0]+' -> '+k[1]+' '+k[2]+''
                for j in k:
                    if arg1==j:
                        if ccount==1:
                            small_t+=f'{i}.txt\n'
                            ccount+=1
                        small_t+=str_k
            if small_t != '':
                small_t+='\n'
            else:
                continue
            transaction+=small_t
            if len(data)!=7 or i==num:
                print(transaction)
    return 0

class P2PNode:
    def __init__(self, port, peers):
        self.port = port
        self.peers = peers
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        hostname=socket.gethostname()
        ip_address=socket.gethostbyname(hostname)
        self.sock.bind((ip_address, self.port)) #此docker的ip

    def start(self):
        threading.Thread(target=self._listen).start()
        threading.Thread(target=self._send_messages).start()

    def _listen(self):
        while True:
            data, addr = self.sock.recvfrom(1024)
            dataS = data.decode('utf-8').split()
            if not dataS:
                continue
            dataS[0]=dataS[0].lower()
            if len(dataS) == 4 and dataS[0] == 'transaction':
                la = dataS[1]
                lb = dataS[2]
                lmoney = dataS[3]
                transaction(la, lb, int(lmoney))
                print(f"\nReceived {data.decode('utf-8')} from docker {addr} !")
            elif len(dataS) == 4 and dataS[0] == 'getmaxsha': 
                ipname=getstrname(ip_address)
                print(f"\nReceived {data.decode('utf-8')} from docker {addr} !")
                max_sha = calculate_sha256(get_max_file())
                print('my sha ',max_sha, len(max_sha))
                print(data)
                print(data.decode('utf-8'))
                if dataS[3] == max_sha:
                    answer=f"{ip_address} max number txt {get_max_file()} sha256 {max_sha} {len(max_sha)} correct!"
                    print('check sha ',max_sha,len(max_sha))
                else:
                    answer=f"{ip_address} max number txt {get_max_file()} sha256 {max_sha} {len(max_sha)} error!"
                    print('check sha ',max_sha, len(max_sha))
                for peer in self.peers:
                    self.sock.sendto(answer.encode('utf-8'), peer)
                transaction('angle',dataS[1],100)                
            else:
                print(f"\nReceived {data.decode('utf-8')} from docker {addr} !")


    def _send_messages(self):
        while True:
            message = input("\nEnter a message or command : (eg.) \n (checklog A , checkmoney A , transaction A B 10, checkChain A, checkallchains A) \n")
            messageS=message.split()
            comlist=['transaction','checkmoney','checklog','checkchain','checkallchains']
            if messageS[0] in comlist:
                if len(messageS)==2 and messageS[0].lower() == 'checkallchains':
                    max_sha = calculate_sha256(get_max_file())
                    getmaxshastr=f'getmaxsha {messageS[1]} {ip_address} {max_sha}'
                    print(f'max number txt: {get_max_file()} , sha: {max_sha} , lengh: {len(max_sha)}')
                    for peer in self.peers:
                        self.sock.sendto(getmaxshastr.encode('utf-8'), peer)
                        time.sleep(1)
                    transaction('angle',messageS[1],100)
                elif len(messageS)==2:
                    global a
                    m=messageS[0]
                    a=messageS[1]
                    m=m.lower()
                    if m == 'checklog':
                        checkLog(a)    
                    if m == 'checkmoney':
                        checkMoney(a)
                    if m == 'checkchain':
                        checkChain(a)
                    else:
                        for peer in self.peers:
                            self.sock.sendto(message.encode('utf-8'), peer)
                elif len(messageS)==4:
                    m=messageS[0]
                    a=messageS[1]
                    b=messageS[2]
                    money=messageS[3]
                    m=m.lower()
                    if m == 'transaction':
                        transaction(a,b,int(money))
                        for peer in self.peers:
                            self.sock.sendto(message.encode('utf-8'), peer)
                    else:
                        for peer in self.peers:
                            self.sock.sendto(message.encode('utf-8'), peer)
                else:
                    for peer in self.peers:
                        self.sock.sendto(message.encode('utf-8'), peer)
            else:
                print('\n error command ! \n')

if __name__ == '__main__':
    port = 8001 #This node's port
    ip_list=['172.17.0.2','172.17.0.3','172.17.0.4']
    ip_list.remove(ip_address)
    peers = [(ip_list[0], 8001), (ip_list[1], 8001)]  #自身外其他兩個docker
    node = P2PNode(port, peers)
    node.start()

