import argparse
import subprocess
import os

bool = True
error_list = []
parser = argparse.ArgumentParser()
parser.add_argument('User_1')
args=parser.parse_args()


with open('block.txt','r') as f:
    Sha=f.readlines()
check=0

if len(Sha)!=0:
    for i in range(1,len(Sha)+1):
        filename = f'{i}.txt'
        result = subprocess.check_output(['sha256sum',filename])
        hash_value = result.decode().split()[0]
        Sha[i-1] = Sha[i-1].split()
        Sha256 = Sha[i-1][0]
        if hash_value  == Sha256:
            #print(Sha256 + f' {i}.txt')
            check +=1
        else:
            bool = False
            error_list.append(Sha256 + f'{i}.txt')
            print(f'error {i}.txt')
    print('Angel get you bonus 10 dollars!')
    command=f'python3 app_transaction.py angel {args.User_1} 10'
    os.system(command)
else:
    print('block.txt have no data!')

if bool == True:
    print("OK")
else:
    print("This id Error Sha256")
    for item in error_list:
        print(item)